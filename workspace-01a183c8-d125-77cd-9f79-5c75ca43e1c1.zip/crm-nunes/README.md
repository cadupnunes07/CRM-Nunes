# CRM Nunes

CRM comercial minimalista para organização de leads e acompanhamento de oportunidades comerciais. Construído com React + Vite + TypeScript, hospedado na Cloudflare Pages, com banco e autenticação via Supabase.

## Estrutura

- `src/` — Código fonte do frontend
- `dist/` — Build de produção (gerado por `npm run build`)
- `wrangler.toml` — Configuração da Cloudflare Pages
- `.env.example` — Exemplo de variáveis de ambiente

## Variáveis de ambiente

Crie um arquivo `.env` na raiz com:

```
VITE_SUPABASE_URL=https://seu-projeto.supabase.co
VITE_SUPABASE_ANON_KEY=sua-chave-anona-do-supabase
```

## Banco de dados (Supabase)

Execute no SQL Editor do Supabase:

```sql
-- Tabela de etapas do pipeline
create table pipeline_stages (
  id text primary key,
  nome text not null,
  ordem integer not null,
  cor text not null
);

-- Tabela de leads
create table leads (
  id uuid default gen_random_uuid() primary key,
  empresa text not null,
  whatsapp text not null,
  email text,
  anotacoes text,
  stage_id text not null references pipeline_stages(id),
  ordem_na_coluna integer not null default 0,
  criado_em timestamptz default now(),
  atualizado_em timestamptz default now(),
  criado_por uuid not null references auth.users(id)
);

-- Habilitar RLS
alter table leads enable row level security;
alter table pipeline_stages enable row level security;

-- Políticas: usuários autenticados podem ler/escrever
create policy "Authenticated users can manage leads" on leads
  for all to authenticated using (true) with check (true);

create policy "Authenticated users can manage stages" on pipeline_stages
  for all to authenticated using (true) with check (true);
```

## Deploy na Cloudflare Pages

### Opção A: Via Git (recomendado)

1. Faça push deste repositório para o GitHub/GitLab.
2. Conecte o repositório na Cloudflare Pages.
3. Configure as variáveis de ambiente `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`.
4. O build command é `npm run build` e o output directory é `dist`.

### Opção B: Via Wrangler CLI

```bash
npm install -g wrangler
wrangler login
wrangler pages deploy dist --project-name=crm-nunes
```

## Scripts disponíveis

- `npm run dev` — Servidor de desenvolvimento
- `npm run build` — Build de produção
- `npm run preview` — Preview local do build

## Funcionalidades

- Kanban com 6 colunas iniciais (editáveis)
- Cadastro, edição e exclusão de leads
- Drag-and-drop entre colunas (mouse)
- Busca instantânea por empresa, WhatsApp ou e-mail
- Link direto para WhatsApp
- Importação e exportação de CSV
- Autenticação de usuários (Supabase Auth)
- Notificações discretas (toast)
- Persistência na nuvem (Supabase PostgreSQL)
