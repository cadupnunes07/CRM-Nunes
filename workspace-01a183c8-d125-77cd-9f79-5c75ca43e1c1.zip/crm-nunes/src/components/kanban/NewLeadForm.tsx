import { useState } from 'react';
import { X } from 'lucide-react';
import type { Lead } from '@/types';

type NewLeadFormProps = {
  onSave: (leadData: Omit<Lead, 'id' | 'criado_em' | 'atualizado_em' | 'criado_por'>) => void;
  onClose: () => void;
};

const DEFAULT_STAGE: Lead['stage_id'] = 'contato-0';

export function NewLeadForm({ onSave, onClose }: NewLeadFormProps) {
  const [empresa, setEmpresa] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [email, setEmail] = useState('');
  const [anotacoes, setAnotacoes] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!empresa.trim()) return;
    onSave({ empresa, whatsapp, email, anotacoes, stage_id: DEFAULT_STAGE, ordem_na_coluna: 0 });
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      onClick={onClose}
    >
      <div className="absolute inset-0 bg-neutral-900/50 backdrop-blur-sm" onClick={onClose} />

      <div className="bg-white rounded-xl shadow-xl w-full max-w-md mx-4" onClick={(e) => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between">
          <h2 className="font-semibold text-neutral-900">Novo lead</h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-neutral-100 rounded-md text-neutral-400 hover:text-neutral-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-medium text-neutral-500 uppercase tracking-wider mb-1">
              Nome da empresa *
            </label>
            <input
              className="input-field"
              value={empresa}
              onChange={(e) => setEmpresa(e.target.value)}
              placeholder="Ex: Loja de Roupas"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-500 uppercase tracking-wider mb-1">
              WhatsApp
            </label>
            <input
              className="input-field"
              value={whatsapp}
              onChange={(e) => setWhatsapp(e.target.value)}
              placeholder="22999999999"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-500 uppercase tracking-wider mb-1">
              E-mail (opcional)
            </label>
            <input
              className="input-field"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="contato@exemplo.com"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-500 uppercase tracking-wider mb-1">
              Anotações
            </label>
            <textarea
              className="input-field h-24"
              value={anotacoes}
              onChange={(e) => setAnotacoes(e.target.value)}
              placeholder="Interesses, objeções, serviços desejados..."
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-neutral-600 bg-neutral-100 hover:bg-neutral-200 rounded-md"
            >
              Cancelar
            </button>
            <button type="submit" className="btn-primary">
              <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
              Cadastrar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
