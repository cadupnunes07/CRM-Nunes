import { useState } from 'react';
import { X, Phone, MessageCircle, Save, Trash2 } from 'lucide-react';
import type { Lead } from '@/types';

type LeadDetailPanelProps = {
  lead: Lead;
  onSave: (id: string, updates: Partial<Pick<Lead, 'empresa' | 'whatsapp' | 'email' | 'anotacoes'>>) => void;
  onDelete: (id: string) => void;
  onClose: () => void;
};

export function LeadDetailPanel({ lead, onSave, onDelete, onClose }: LeadDetailPanelProps) {
  const [empresa, setEmpresa] = useState(lead.empresa);
  const [whatsapp, setWhatsapp] = useState(lead.whatsapp);
  const [email, setEmail] = useState(lead.email);
  const [anotacoes, setAnotacoes] = useState(lead.anotacoes);
  const [saving, setSaving] = useState(false);

  const handleSave = () => {
    setSaving(true);
    onSave(lead.id, { empresa, whatsapp, email, anotacoes });
    setSaving(false);
  };

  const whatsappLink = `https://wa.me/${lead.whatsapp.replace(/\D/g, '')}`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Detalhes do lead"
    >
      <div className="absolute inset-0 bg-neutral-900/50 backdrop-blur-sm transition-opacity" onClick={onClose} />

      <div
        className="bg-white rounded-xl shadow-xl w-full max-w-md mx-4 max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between">
          <h2 className="font-semibold text-neutral-900">Detalhes do lead</h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-neutral-100 rounded-md text-neutral-400 hover:text-neutral-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          <div>
            <label className="block text-xs font-medium text-neutral-500 uppercase tracking-wider mb-1">
              Nome da empresa
            </label>
            <input
              className="input-field"
              value={empresa}
              onChange={(e) => setEmpresa(e.target.value)}
              required
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-500 uppercase tracking-wider mb-1">
              WhatsApp
            </label>
            <div className="flex gap-2">
              <input
                className="input-field flex-1"
                value={whatsapp}
                onChange={(e) => setWhatsapp(e.target.value)}
              />
              <a
                href={whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700"
              >
                <Phone className="w-4 h-4 mr-1" /> Abrir
              </a>
            </div>
            <p className="text-xs text-neutral-400 mt-1">Formato: com DDD, ex: 22999999999</p>
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-500 uppercase tracking-wider mb-1">
              E-mail (opcional)
            </label>
            <input
              className="input-field"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-500 uppercase tracking-wider mb-1">
              Anotações
            </label>
            <textarea
              className="input-field h-32"
              value={anotacoes}
              onChange={(e) => setAnotacoes(e.target.value)}
            />
          </div>
        </div>

        <div className="px-6 py-4 border-t border-neutral-200 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs text-neutral-500">
            <MessageCircle className="w-3 h-3" />
            <span>Criado em: {new Date(lead.criado_em).toLocaleDateString('pt-BR')}</span>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => {
                onDelete(lead.id);
                onClose();
              }}
              className="flex items-center gap-1 px-3 py-2 text-sm font-medium text-red-600 bg-red-50 hover:bg-red-100 rounded-md"
            >
              <Trash2 className="w-4 h-4" /> Excluir
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              className="btn-primary"
            >
              {saving ? 'Salvando...' : (
                <>
                  <Save className="w-4 h-4 mr-2" /> Salvar
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
