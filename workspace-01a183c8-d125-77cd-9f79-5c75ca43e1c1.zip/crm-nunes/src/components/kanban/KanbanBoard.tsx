import { useCallback, useState } from 'react';
import { Plus, User } from 'lucide-react';
import type { Lead, Stage } from '@/types';
import { useLeads } from '@/hooks/useLeads';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/components/ui/Toast';
import { StageColumn } from './StageColumn';
import { LeadDetailPanel } from './LeadDetailPanel';
import { NewLeadForm } from './NewLeadForm';
import { PipelineConfig } from './PipelineConfig';
import { getDraggedLeadId, setDraggedLeadId } from '@/lib/dragState';

export function KanbanBoard() {
  const { user, signOut } = useAuth();
  const { leads, stages, loading, createLead, updateLead, deleteLead, moveLead, importLeads, exportLeads } = useLeads();
  const { add, Toast } = useToast();

  const [openLead, setOpenLead] = useState<Lead | null>(null);
  const [newLeadOpen, setNewLeadOpen] = useState(false);
  const [pipelineConfigOpen, setPipelineConfigOpen] = useState(false);
  const [search, setSearch] = useState('');

  const filteredLeads = leads.filter(
    (l: Lead) =>
      l.empresa.toLowerCase().includes(search.toLowerCase()) ||
      l.whatsapp.toLowerCase().includes(search.toLowerCase()) ||
      l.email.toLowerCase().includes(search.toLowerCase()),
  );

  const handleLeadDrop = useCallback(
    async (stageId: Stage['id'], draggedLeadId: string, targetIndex: number) => {
      const lead = filteredLeads.find((l: Lead) => l.id === draggedLeadId);
      if (!lead) return;

      const newOrdem = targetIndex;

      try {
        await moveLead(draggedLeadId, stageId, newOrdem);
        const nomeStage = stages.find((s: Stage) => s.id === stageId)?.nome ?? '';
        add(`Lead movido para "${nomeStage}"`, 'success');
      } catch {
        add('Erro ao mover lead. Tente novamente.', 'error');
      }
    },
    [filteredLeads, moveLead, stages, add],
  );

  const handleCreateLead = useCallback(
    async (leadData: Omit<Lead, 'id' | 'criado_em' | 'atualizado_em' | 'criado_por'>) => {
      try {
        await createLead(leadData);
        add('Lead cadastrado com sucesso', 'success');
        setNewLeadOpen(false);
      } catch {
        add('Erro ao cadastrar lead', 'error');
      }
    },
    [createLead, add],
  );

  const handleUpdateLead = useCallback(
    async (id: string, updates: Partial<Pick<Lead, 'empresa' | 'whatsapp' | 'email' | 'anotacoes'>>) => {
      try {
        await updateLead(id, updates);
        add('Lead atualizado', 'success');
        setOpenLead(null);
      } catch {
        add('Erro ao atualizar lead', 'error');
      }
    },
    [updateLead, add],
  );

  const handleDeleteLead = useCallback(
    async (id: string) => {
      if (!window.confirm('Tem certeza que deseja excluir este lead?')) return;
      try {
        await deleteLead(id);
        add('Lead excluído', 'success');
        setOpenLead(null);
      } catch {
        add('Erro ao excluir lead', 'error');
      }
    },
    [deleteLead, add],
  );

  const handleImport = async (file: File) => {
    const text = await file.text();
    try {
      const result = await importLeads(text);
      add(`${result.inserted} lead(s) importado(s)`, 'success');
    } catch {
      add('Erro ao importar CSV', 'error');
    }
  };

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="flex flex-col items-center gap-2">
          <div className="w-8 h-8 border-2 border-neutral-300 border-t-neutral-900 rounded-full animate-spin" />
          <p className="text-neutral-600 text-sm">Carregando CRM...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <Toast />

      {/* Header */}
      <header className="bg-white border-b border-neutral-200 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-600 rounded-md flex items-center justify-center text-white font-bold text-sm">
            CN
          </div>
          <h1 className="font-semibold text-neutral-900">CRM Nunes</h1>
        </div>

        <div className="flex items-center gap-4">
          {/* Busca */}
          <div className="relative">
            <input
              type="text"
              placeholder="Buscar empresa, WhatsApp ou e-mail..."
              className="input-field pl-9"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <button
            onClick={() => setNewLeadOpen(true)}
            className="btn-primary"
          >
            <Plus className="w-4 h-4 mr-2" /> Novo lead
          </button>

          <button onClick={exportLeads} className="btn-ghost" title="Exportar CSV">
            <User className="w-4 h-4" />
          </button>

          <button
            onClick={() => setPipelineConfigOpen(true)}
            className="btn-ghost" title="Configurar pipeline"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
            </svg>
          </button>

          <div className="w-8 h-8 rounded-full bg-neutral-100 flex items-center justify-center text-neutral-600 text-sm font-medium">
            {user?.email?.split('@')[0] ?? 'U'}
          </div>
          <button
            onClick={signOut}
            className="text-xs text-neutral-500 hover:text-red-600"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="w-3 h-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7" />
            </svg>
            Sair
          </button>
        </div>
      </header>

      <main className="p-4">
        {/* Import CSV (discreto) */}
        <div className="mb-4 flex items-center gap-2 text-xs text-neutral-500">
          <span>Importar CSV:</span>
          <input type="file" accept=".csv" className="hidden" id="csv-import" onChange={(e) => {
            if (e.target.files?.[0]) handleImport(e.target.files[0]);
          }} />
          <label
            htmlFor="csv-import"
            className="text-blue-600 hover:underline cursor-pointer"
          >
            Selecionar arquivo
          </label>
        </div>

        {/* Kanban */}
        <div className="flex gap-4 overflow-x-auto pb-4">
          {stages.map((stage: Stage) => {
            const stageLeads = filteredLeads.filter((l: Lead) => l.stage_id === stage.id);
            return (
              <StageColumn
                key={stage.id}
                stage={stage}
                leads={stageLeads}
                onLeadClick={setOpenLead}
                onDragOver={() => {}}
                onDrop={(stageId: Stage['id']) => {
                  const draggedId = getDraggedLeadId();
                  if (!draggedId) return;
                  const targetIndex = stageLeads.length;
                  handleLeadDrop(stageId, draggedId, targetIndex);
                  setDraggedLeadId(null);
                }}
                onEditStage={() => setPipelineConfigOpen(true)}
                onDeleteStage={() => {
                  if (window.confirm('Excluir esta etapa? Os leads serão movidos para Contato 0.')) {
                    setPipelineConfigOpen(true);
                  }
                }}
              />
            );
          })}
        </div>
      </main>

      {openLead && (
        <LeadDetailPanel
          lead={openLead}
          onSave={handleUpdateLead}
          onDelete={handleDeleteLead}
          onClose={() => setOpenLead(null)}
        />
      )}

      {newLeadOpen && (
        <NewLeadForm
          onSave={handleCreateLead}
          onClose={() => setNewLeadOpen(false)}
        />
      )}

      {pipelineConfigOpen && (
        <PipelineConfig
          stages={stages}
          onClose={() => setPipelineConfigOpen(false)}
        />
      )}
    </div>
  );
}
