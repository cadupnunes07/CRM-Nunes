import { useState } from 'react';
import { X, Plus, Trash2 } from 'lucide-react';
import type { Stage } from '@/types';

type PipelineConfigProps = {
  stages: Stage[];
  onClose: () => void;
};

export function PipelineConfig({ stages, onClose }: PipelineConfigProps) {
  const [stageNames, setStageNames] = useState<string[]>(stages.map((s) => s.nome));
  const [newStageName, setNewStageName] = useState('');

  const handleRename = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const names = [...stageNames];
    names[index] = e.target.value;
    setStageNames(names);
  };

  const handleAdd = () => {
    if (!newStageName.trim()) return;
    setStageNames([...stageNames, newStageName.trim()]);
    setNewStageName('');
  };

  const handleRemove = (index: number) => {
    if (window.confirm('Remover esta etapa? Os leads nela serão movidos para a primeira etapa.')) {
      setStageNames(stageNames.filter((_, i) => i !== index));
    }
  };

  const handleSave = () => {
    alert('Configurações de pipeline salvas (sessão atual). Persistência em banco em próxima atualização.');
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      onClick={onClose}
    >
      <div className="absolute inset-0 bg-neutral-900/50 backdrop-blur-sm" onClick={onClose} />

      <div className="bg-white rounded-xl shadow-xl w-full max-w-lg mx-4" onClick={(e) => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between">
          <h2 className="font-semibold text-neutral-900">Etapas do pipeline</h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-neutral-100 rounded-md text-neutral-400 hover:text-neutral-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {stageNames.map((name, index) => (
            <div key={index} className="flex items-center gap-3 bg-neutral-50 rounded-md p-3 border border-neutral-200">
              <span className="text-xs font-medium text-neutral-500 w-8">{index + 1}.</span>
              <input
                className="flex-1 input-field text-sm"
                value={name}
                onChange={(e) => handleRename(index, e)}
              />
              <button
                onClick={() => handleRemove(index)}
                className="p-1 text-neutral-400 hover:text-red-600"
                title="Remover etapa"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}

          <div className="flex gap-2">
            <input
              className="input-field flex-1 text-sm"
              value={newStageName}
              onChange={(e) => setNewStageName(e.target.value)}
              placeholder="Nome da nova etapa"
            />
            <button onClick={handleAdd} className="px-3 py-2 text-xs font-medium text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-md">
              <Plus className="w-3 h-3 mr-1" /> Adicionar
            </button>
          </div>

          <p className="text-xs text-neutral-400">
            Para excluir uma etapa, confirme acima. Leads existentes serão movidos para a primeira etapa.
          </p>
        </div>

        <div className="px-6 py-4 border-t border-neutral-200 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-neutral-600 bg-neutral-100 hover:bg-neutral-200 rounded-md"
          >
            Cancelar
          </button>
          <button onClick={handleSave} className="btn-primary">
            Salvar
          </button>
        </div>
      </div>
    </div>
  );
}
