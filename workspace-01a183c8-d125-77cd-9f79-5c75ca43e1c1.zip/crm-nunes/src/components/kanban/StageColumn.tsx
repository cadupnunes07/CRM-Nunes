import { useCallback } from 'react';
import { Plus, Trash2, Edit3 } from 'lucide-react';
import type { Lead, Stage } from '@/types';
import { LeadCard } from './LeadCard';

type StageColumnProps = {
  stage: Stage;
  leads: Lead[];
  onLeadClick: (lead: Lead) => void;
  onDragOver: (stageId: Stage['id']) => void;
  onDrop: (stageId: Stage['id']) => void;
  onEditStage: (stage: Stage) => void;
  onDeleteStage: (stage: Stage) => void;
};

export function StageColumn({
  stage,
  leads,
  onLeadClick,
  onDragOver,
  onDrop,
  onEditStage,
  onDeleteStage,
}: StageColumnProps) {
  const stageLeads = leads;

  const handleDragOver = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      onDragOver(stage.id);
    },
    [stage.id, onDragOver],
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      const leadId = e.dataTransfer?.getData('application/lead-id');
      if (leadId) {
        onDrop(stage.id);
      }
    },
    [stage.id, onDrop],
  );

  return (
    <div
      className="flex flex-col w-[320px] shrink-0"
      onDragOver={handleDragOver}
      onDrop={handleDrop}
    >
      <div
        className={`stage-header bg-neutral-100 mb-2`}
        style={{ borderLeft: `4px solid ${stageColor(stage.id)}` }}
      >
        <div className="flex items-center gap-2">
          <span className="font-semibold text-neutral-800">{stage.nome}</span>
          <span className="ml-auto text-xs font-medium text-neutral-500 bg-neutral-200 px-2 py-0.5 rounded-full">
            {stageLeads.length}
          </span>
        </div>
        <div className="flex items-center gap-1 mt-2 pt-2 border-t border-neutral-200">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onEditStage(stage);
            }}
            className="p-1 text-neutral-400 hover:text-neutral-600"
            aria-label="Editar etapa"
          >
            <Edit3 className="w-3 h-3" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onDeleteStage(stage);
            }}
            className="p-1 text-neutral-400 hover:text-red-600"
            aria-label="Excluir etapa"
          >
            <Trash2 className="w-3 h-3" />
          </button>
        </div>
      </div>

      <div className="flex-1 min-h-[400px] bg-neutral-50 rounded-lg p-2 space-y-2">
        {stageLeads.map((lead: Lead) => (
          <LeadCard key={lead.id} lead={lead} onOpenDetail={onLeadClick} />
        ))}
        {stageLeads.length === 0 && (
          <div className="h-8 flex items-center justify-center text-xs text-neutral-400 bg-neutral-100 rounded-md">
            Vazio
          </div>
        )}
      </div>

      <button
        onClick={(e) => {
          e.stopPropagation();
        }}
        className="mt-2 w-full py-1.5 px-3 rounded-md text-xs text-neutral-500 hover:bg-neutral-100 border border-neutral-200 transition-colors"
      >
        <Plus className="w-3 h-3 mr-1" /> Adicionar
      </button>
    </div>
  );
}

function stageColor(stageId: Stage['id']): string {
  const colors: Record<Stage['id'], string> = {
    'contato-0': '#bfdbfe',
    'primeiro-contato': '#93c5fd',
    negociacao: '#fcd34d',
    proposta: '#f87171',
    fechado: '#4ade80',
    perdido: '#f87171',
  };
  return colors[stageId] ?? '#cbd5e1';
}
