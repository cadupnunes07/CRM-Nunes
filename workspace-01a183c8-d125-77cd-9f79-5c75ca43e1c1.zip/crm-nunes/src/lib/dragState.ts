export let draggedLeadId: string | null = null;

export function setDraggedLeadId(id: string | null) {
  draggedLeadId = id;
}

export function getDraggedLeadId(): string | null {
  return draggedLeadId;
}
