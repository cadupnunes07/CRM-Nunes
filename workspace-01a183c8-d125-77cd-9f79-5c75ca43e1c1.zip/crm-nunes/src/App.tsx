import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { KanbanBoard } from '@/components/kanban/KanbanBoard';
import { Login } from '@/pages/Login';

function RequireAuth({ children }: { children: React.ReactNode }) {
  const { user, loading, isAuthenticated } = useAuth();
  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <p className="text-neutral-600">Carregando autenticação...</p>
      </div>
    );
  }
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
}

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/kanban"
          element={
            <RequireAuth>
              <KanbanBoard />
            </RequireAuth>
          }
        />
        <Route path="/" element={<Navigate to="/kanban" replace />} />
      </Routes>
    </AuthProvider>
  );
}
