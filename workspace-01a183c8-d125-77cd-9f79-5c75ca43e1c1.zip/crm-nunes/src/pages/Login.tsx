import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { Lock, User as UserIcon } from 'lucide-react';

export function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [loading, setLoading] = useState(false);
  const { signIn, signUp } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === 'login') {
        const { error } = await signIn(email, password);
        if (error) throw error;
        navigate('/kanban');
      } else {
        const { error } = await signUp(email, password);
        if (error) throw error;
        alert('Conta criada! Verifique seu e-mail para confirmar o cadastro.');
        setMode('login');
      }
    } catch (err: any) {
      alert(err.message || 'Erro ao autenticar');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex h-screen items-center justify-center bg-neutral-100">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-8">
        <div className="text-center mb-8">
          <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold mx-auto mb-4">
            CN
          </div>
          <h1 className="text-2xl font-bold text-neutral-900">CRM Nunes</h1>
          <p className="text-neutral-500 text-sm">Acesso à pipeline comercial</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center gap-3 p-2 rounded-md border border-neutral-200 bg-neutral-50">
              <UserIcon className="w-4 h-4 text-neutral-400" />
              <input
                className="flex-1 outline-none text-sm"
                type="email"
                placeholder="E-mail"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="flex items-center gap-3 p-2 rounded-md border border-neutral-200 bg-neutral-50">
              <Lock className="w-4 h-4 text-neutral-400" />
              <input
                className="flex-1 outline-none text-sm"
                type="password"
                placeholder="Senha"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn-primary w-full"
          >
            {loading ? 'Entrando...' : mode === 'login' ? 'Entrar' : 'Criar conta'}
          </button>
        </form>

        <p className="mt-6 text-center text-xs text-neutral-500">
          {mode === 'login'
            ? 'Não tem uma conta? '
            : 'Já tem uma conta? '}
          <button
            onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}
            className="text-blue-600 font-medium hover:underline"
          >
            {mode === 'login' ? 'Cadastre-se' : 'Entrar'}
          </button>
        </p>

        <p className="mt-4 text-center text-[10px] text-neutral-400">
          CRM Nunes — sistema minimalista para organização de leads
        </p>
      </div>
    </div>
  );
}
